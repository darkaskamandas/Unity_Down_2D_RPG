﻿using UnityEngine;
using System.Collections;

public class GeneralShop : Shop {
	
	void Start () {
	
	}

	void Update () {
	
	}
}
