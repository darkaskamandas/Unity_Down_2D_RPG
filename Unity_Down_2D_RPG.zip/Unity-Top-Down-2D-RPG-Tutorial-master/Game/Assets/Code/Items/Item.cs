﻿using UnityEngine;
using System.Collections;

public class Item : MonoBehaviour {

	public string itemName;
	public string itemDescrition;
	public int id;

	public Sprite itemSprite;

	void Start () {
	
	}
	
	void Update () {
	
	}
}
